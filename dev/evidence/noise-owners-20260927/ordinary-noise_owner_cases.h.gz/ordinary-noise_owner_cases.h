/* Generated test-only provider sensitivity inputs. */
typedef struct { const char *name; size_t pending, active, draining, slots; } owner_case;
static const owner_case owner_cases[] = {
{"single", 1, 1, 1, 1},
{"four_serial", 4, 4, 4, 1},
{"four_parallel", 4, 4, 4, 2},
};
typedef struct { const char *name; size_t retained; } owner_budget;
static const owner_budget owner_budgets[] = {
{"small", 8192},
{"medium", 16384},
{"large", 32768},
};
